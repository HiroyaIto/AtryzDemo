/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021, 2023 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name        : Config_IT.c
* Component Version: 1.4.0
* Device(s)        : R5F12017xSP
* Description      : This file implements device driver for Config_IT.
***********************************************************************************************************************/
/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"
#include "Config_IT.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_IT_Create
* Description  : This function initializes the IT module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_IT_Create(void)
{
    TMKAEN = 1U;					// �N���b�N����
    ITMC = _0000_IT_COUNTER_STOP;	// �J�E���g�����~
    ITMK = 1U;						// INTIT���荞�݋֎~
    ITIF = 0U;						// INTIT���荞�݃t���O�N���A

	// ���荞�݃��x���R�ݒ�
    ITPR1 = 1U;
    ITPR0 = 1U;

    ITMC = _05DB_IT_ITMC_VALUE;		// 100ms�^�C�}�l�ݒ�

    R_Config_IT_Create_UserInit();	// ���[�U�[�����ݒ�i�K�v�Ȃ��j
}

/***********************************************************************************************************************
* Function Name: R_Config_IT_Start
* Description  : This function starts the IT module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_IT_Start(void)
{
    ITIF = 0U;							// INTIT���荞�݃t���O�N���A
    ITMK = 0U;							// INTIT���荞�݋���
    ITMC |= _8000_IT_COUNTER_START;		// �P�Q�r�b�g�^�C�} �J�E���g�X�^�[�g
}

/***********************************************************************************************************************
* Function Name: R_Config_IT_Stop
* Description  : This function stops the IT module operation.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_IT_Stop(void)
{
    ITMK = 1U;    /* disable INTIT interrupt */
    ITIF = 0U;    /* clear INTIT interrupt flag */
    ITMC &= (uint16_t)~_8000_IT_COUNTER_START;    /* disable IT operation */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

