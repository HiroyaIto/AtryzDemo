/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2016, 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_cg_main.c
* Version      : Code Generator for RL78/G11 V1.02.06.02 [08 Nov 2021]
* Device(s)    : R5F1054A
* Tool-Chain   : CCRL
* Description  : This file implements main function.
* Creation Date: 2022/09/12
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_cgc.h"
#include "r_cg_port.h"
#include "r_cg_tau.h"
#include "r_cg_dac.h"
#include "r_cg_intp.h"
/* Start user code for include. Do not edit comment generated here */
#include "define.h"
#include "Typedef.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
void main(void);

extern void Stop_bit(void);
extern void R_DAC1_Set_ConversionValue(uint8_t regvalue);
extern void wait_1us(UC loop);
extern void R_TAU0_Channel0_Start(void);
extern void R_DAC1_Start(void);
extern void SX9331_init(void);
extern UC REG_read(US data);
extern UC I2C_read_4byte(US reg);
extern UC I2C_write_4byte(US reg,UL value);
extern UC I2C_read_1byte(void);
extern UC I2C_send(void);

/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
US	main_1ms = 0;				// ���C���̎��ԏ����p
US	test_1ms = 0;
UC	DA_data = 0;				// �o��D/A�f�[�^�i8�r�b�g�j
UL	Raw_data;					// Raw�f�[�^
UL	Ave_data;					// Ave�f�[�^
UL	Diff_data;					// Diff�f�[�^
UL	Ref_data;					// Ref�f�[�^
UC	sit;						// �����f�[�^

UL	check_data;

UL	backup = 0;

UL for_counter = 0;             // add 20220714 H.Sugawara
UL mul_threshold = 0;           // add 20220714 H.Sugawara
extern const UL SetData[];      // add 20220714 H.Sugawara
RegStat0_st RegStat0_data;      // add 20220803 H.Sugawara
US scan_period = 0;             // add 20220803 H.Sugawara
UC	sit_latch=0;	        // add 20220912 H.Sugawara
extern  UL f_1s;                // add 20220912 H.Sugawara
UL adc_result;
float ani_voltage;

extern	UC	f_1ms;
extern	UL	AD_data;			// �ǂݏo�� A/D�f�[�^
extern	UC	dip3;				// DIP�X�C�b�`�ݒ�
/* End user code. Do not edit comment generated here */

static void R_MAIN_UserInit(void);
/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
    R_MAIN_UserInit();
    /* Start user code. Do not edit comment generated here */
    // add 20220714 H.Sugawara
    check_data = 0;
    for(for_counter=0; for_counter < 115; for_counter++)
    {
        switch( SetData[(for_counter<<1)]) 
        {
            case 0x8054: // 臒l���W�X�^�ł���Ύ擾
                switch((SetData[(for_counter<<1)+1] >> 24) & 0x00000007)
                {
                    default  : mul_threshold =  1; break;
                    case 0x00: mul_threshold =  1; break;
                    case 0x01: mul_threshold =  2; break;
                    case 0x02: mul_threshold =  4; break;
                    case 0x03: mul_threshold =  8; break;
                    case 0x04: mul_threshold = 16; break;
                    case 0x05: mul_threshold = 32; break;
                    case 0x06: mul_threshold = 64; break;
                    case 0x07: mul_threshold =  1; break;
                }
    			check_data  = ((SetData[(for_counter<<1)+1] >> 8) & 0x000000FF);
    			check_data *= check_data;
    			check_data /= 2;
                check_data *= mul_threshold;
                break;
                
            case 0x801C: // Scan�s���I�h���W�X�^�ł���Ύ擾
                scan_period = 2.048 * (SetData[(for_counter<<1)+1] & 0x000007FF); // SCANPERIOD * (8192 / FOsc)
                break;
                
            default: break;
        }
    }
    // end 20220714 H.Sugawara
    

	SX9331_init();					// SX9331 �����ݒ�f�[�^�������ݏ���

	main_1ms = 0;
	while(main_1ms < 300)			// 300ms�҂�
	{
		if(f_1ms)
		{
			f_1ms = 0;
			++main_1ms;
		}
	}
	main_1ms = 0;
	I2C_write_4byte(0x4280, 0x0000000F);		// PHEN�Ŏw�肳�ꂽ�t�F�[�Y��L���ɂ���
	I2C_write_4byte(0x8004, 0x00010000);		// COMPENSATION�L���ɂ��� Otagaki0714

    while (1U)
    {
		if(f_1ms)					// �P�����o�߁H
		{							// yes
			f_1ms = 0;				// �P�����o�߃N���A
			++main_1ms;				// ���C���p�P�����J�E���^�{�P

			++test_1ms;

			/*--------------------------------------*/
			/*		PROXFIFF �ǂݏo��				*/
			/*--------------------------------------*/
			//if(main_1ms >= 100)		// �P�O�O�����o�߁H
			if(main_1ms >= scan_period) // Scan�����ʉ߁H 20220803 H.Sugawara
			{						// yes
				main_1ms = 0;		// �o�ߎ��Ԃ��O�ɖ߂�
				if(REG_read(Diff) == OK)				// PROXDIFF(CH0)�ǂݏo�� ACK�G���[�����H
				{										// yes
//					Diff_data = AD_data;				// Diff�f�[�^�i�[ Otagaki 0714
					//if(AD_data & 0x80000000)	AD_data = 0L;		// 	A/D���}�C�i�X�̎��̓f�[�^���O�ɂ���
					//else AD_data &= 0xFFFFFC00;						// ����10�r�b�g�͂O�ɂ���
					//AD_data = AD_data >> 10;			// 10bit�V�t�g    Otagaki 0714
					//Diff_data = AD_data;				// Diff�f�[�^�i�[ Otagaki 0714
                    // add 20220803 H.Sugawara
                    if(REG_read(Stat) == OK){ // RegStat0��ǂݏo��
                        RegStat0_data.ul = AD_data;
                    }
                    // end 20220803 H.Sugawara
                    
					/*------------------------------*/
					/*		�����o�͐ݒ�			*/
					/*------------------------------*/
//					if(AD_data >= SIT_VALUE)
					//if(AD_data >= check_data)		// DIP3�̃f�[�^�Ɣ�r
//					//if(Diff_data >= check_data)		// DIP3�̃f�[�^�Ɣ�r Otagaki0714
                    if(RegStat0_data.bit.PROXSTAT & PH0) // RegStat0�APROXSTAT��PH0�t���O 20220803 H.Sugawara
					{
						Set_SIT(ON);			// �����o��ON�iLow�o�́j
						Set_LED(ON);			// LED ON�iHigh�o�́j
						sit = 1;
					}
					else
					{
						Set_SIT(OFF);			// �����o�͂n�e�e�iLow�o�́j
						Set_LED(OFF);			// LED OFF�iHigh�o�́j
						sit = 0;
					}
					backup = AD_data;
				}
				if(REG_read(Raw) == OK)	Raw_data = AD_data;			// Raw�f�[�^�ǂݏo��
				else	Raw_data = 0L;
				if(REG_read(Ave) == OK)	Ave_data = AD_data;			// Ave�f�[�^�ǂݏo��
				else	Ave_data = 0L;
				if(REG_read(Ref) == OK) Ref_data = AD_data;			// Ref�f�[�^�ǂݏo��
				else	Ref_data = 0L;

				// �f�o�b�O
//				Raw_data = 0x7F010203;
//				Ave_data = 0x40050607;
//				Diff_data = 0x20090A0B;
//				Ref_data = 0x100D0E0F;
//				sit = 0x12;
				// �����܂�

				/*--------------------------------------*/
				/*		�����@�Ƃ�I2C�ʐM				*/
				/*--------------------------------------*/
				I2C_read_1byte();				// Dip�X�C�b�`�̓ǂݍ���
				I2C_send();					// �f�[�^���M

				//check_data = dip_table[dip3];
				//check_data = 55696;			// 臒l
				//check_data = 0x00018610;			// 臒l
				check_data = 0x000186a0;			// 臒lOtagaki0714

				/*--------------------------------------*/
				/*		SX9331 A/D�l��D/A�o�͂���		*/
				/*--------------------------------------*/
				AD_data = backup;
				if(AD_data & 0x80000000)		// A/D �}�C�i�X�H
				{								// yes
					DA_data = 0;				// D/A�f�[�^���O�ɂ���
				}
				else							// A/D �v���X
				{
					DA_data = (UC)((AD_data >> 25) & 0x000000FF);	// ���������������8�r�b�g��ݒ肷��
				}
				R_DAC1_Set_ConversionValue(DA_data);	// D/A�o��
			}
		}

    }
    /* End user code. Do not edit comment generated here */
}
/***********************************************************************************************************************
* Function Name: R_MAIN_UserInit
* Description  : This function adds user code before implementing main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void R_MAIN_UserInit(void)
{
    /* Start user code. Do not edit comment generated here */
 
	Stop_bit();					// I2C STOP��Ԃɂ���
	wait_1us(10);				// 10us�҂�
	R_TAU0_Channel0_Start();	// �^�C�}�O �X�^�[�g
	R_DAC1_Start();				// D/A �X�^�[�g

	EI();

    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
