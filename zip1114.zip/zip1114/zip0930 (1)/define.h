/****************************************************************/
/* File Name   : define.h										*/
/* Model       : 												*/
/*--------------------------------------------------------------*/
/* History	   : 												*/
/****************************************************************/
#define		KINSETSU		0				// 0:�^�b�` 1:�ߐ� �^�b�`/�ߐڂ̔���ؑ�

#define		ON				1
#define		OFF				0
#define		OUT				0
#define		IN				1
#define		OK				0
#define		NG				1


/*------------------------------------------*/
/*		�o�n�q�s							*/
/*------------------------------------------*/
#define SDA_port		0b00000010			// P0_1	I2C SDA�|�[�g
#define Set_SDA(m)		m?(P0 |= SDA_port):	(P0 &= ~SDA_port)
#define Dir_SDA(m)		m?(PM0 |= SDA_port): (PM0 &= ~SDA_port)

#define	ACK				(P0 & SDA_port)

#define SCL_port		0b00000100			// P0_2	I2C SCL�|�[�g
#define Set_SCL(m)		m?(P0 |= SCL_port):	(P0 &= ~SCL_port)

#define SIT_port		0b00000001			// P0_0 �������m�o�͐M�� (High:�����j
#define	Set_SIT(m)		m?(P0 |= SIT_port):	(P0 &= ~SIT_port)

#define	TEST_port		0b00001000			// P0_3 L:test H:Normal �ύX L:Normal H:test
#define	TEST_in			(P0 & TEST_port)

/*------------------------------------------*/
/*		��������A/D�l						*/
/*------------------------------------------*/
#if		KINSETSU
	#define	SIT_VALUE		0x00100000			// ��������l�i�ߐځj
#else
	#define	SIT_VALUE		0x28000000			// ��������l(�^�b�`�j
#endif

#define	Raw				0
#define	Ave				1
#define	Diff			2
#define	Ref				3
#define	Stat			4   // add 20220803 H.Sugawara

/*------------------------------------------*/
/*		�r�w�X�R�R�P ���W�X�^�A�h���X		*/
/*------------------------------------------*/
#define	RegUsePh0		0x815C				// Raw
#define	RegAvgPh0		0x8174				// Ave
#define	RegDiffPh0		0x818C				// Diff
#define	RegUsePh1		0x8160				// Ref
#define	RegStat0		0x8000				// RegStat0 add 20220803 H.Sugawara

#define	RegCmd			0x4280				// Command

